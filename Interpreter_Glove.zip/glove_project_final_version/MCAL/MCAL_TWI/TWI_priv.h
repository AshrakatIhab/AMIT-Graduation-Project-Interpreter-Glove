/*
 * TWI_priv.h
 *
 *  Created on: FEB 1, 2019
 *      Author: Khaled Mohsen
 */

#ifndef TWI_PRIV_H_
#define TWI_PRIV_H_

#define TWBR (*((volatile u8 *)0x20))  //bit rate register
#define TWCR (*((volatile u8 *)0x56))  //control register
#define TWSR (*((volatile u8 *)0x21))  //status register
#define TWDR (*((volatile u8 *)0x23))  //data register
#define TWAR (*((volatile u8 *)0x22))  //address register

/*TWCR Register*/

#define TWINT   7  //interrupt, auto raised (to 0) after any task, must be cleared (to 1) with software
#define TWEA	6  //ACK enable, set in receiver mode to generate bit, and cleared in transmit mode (if cleared, device is disconnected from twi connection)
#define TWSTA   5  //start condition bit
#define TWSTO	4  //stop condition bit
#define TWWC	3  //write collision, set when writing to data register b4 transmission is complete, TWINT is low (1)
#define TWEN	2  //enable
//#define TWBR1	1  reserved bit
#define TWIE	0  //interrupt enable

/* TWSR Register */  //pre-scaler bits
#define TWPS1	1
#define TWPS0	0


#endif /* TWI_PRIV_H_ */
