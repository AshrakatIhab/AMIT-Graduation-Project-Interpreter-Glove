/*
 * TWI_config.h
 *
 *  Created on: FEB 1, 2019
 *      Author: Khaled Mohsen
 */

#ifndef TWI_CONFIG_H_
#define TWI_CONFIG_H_



#endif /* TWI_CONFIG_H_ */
