/****************************************/
/*          Author: Khaled Mohsen       */        
/*          Date: 3-9-2022              */
/*          Version: 1.0                */
/*          Module: LCD                 */
/****************************************/
#ifndef LCD_PRIVATE_H_
#define LCD_PRIVATE_H_

#define LCD_U8_4_BIT  0
#define LCD_U8_8_BIT  1

                      
#endif