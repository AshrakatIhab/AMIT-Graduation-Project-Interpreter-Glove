/****************************************/
/*          Author: Khaled Mohsen       */        
/*          Date: 3-9-2022              */
/*          Version: 1.0                */
/*          Module: LCD                 */
/****************************************/
#include "../../service/STD_types.h"
#include "../../service/BIT_math.h"
#include "../../MCAL/MCAL_DIO/DIO_int.h"
#include "../../HAL/HAL_LCD/LCD_int.h"
#include "../../HAL/HAL_LCD/LCD_private.h"
#include "../../HAL/HAL_LCD/LCD_config.h"
#define F_CPU 16000000UL
#include <util/delay.h>

void LCD_voidInit(void)
{	
	#if LCD_U8_DATA_LENGTH == LCD_U8_4_BIT
		_delay_ms(35);
		LCD_voidSendCommand(0x33); //00110011
		_delay_ms(2);
		LCD_voidSendCommand(0x32); //00110010
		_delay_ms(2);
		LCD_voidSendCommand(0x28); //00101000
		_delay_ms(2);
		LCD_voidSendCommand(0x0c); //00001100
		_delay_ms(2);
		LCD_voidSendCommand(00000111); //00000110 = 0x06   changed to 00000111
		_delay_ms(2);
		LCD_voidSendCommand(0x01); //00000001
		_delay_ms(2);

	#elif LCD_U8_DATA_LENGTH == LCD_U8_8_BIT		
			_delay_ms(35);
			LCD_voidSendCommand(0x38); //2 lines and 5�7 matrix (8-bit mode)      00111000
			_delay_ms(1);
			LCD_voidSendCommand(0x0c); //Display on, cursor off                   00001100
			_delay_ms(1);
			LCD_voidSendCommand(0x01); //Clear display screen                     00000001
			_delay_ms(2);
			LCD_voidSendCommand(0x06); //Decrement cursor (shift cursor to left)  00000110
			
	#endif
}
void LCD_voidSendData(u8 Copy_u8Data)
{
	DIO_voidSetPinValue(LCD_U8_RS,DIO_U8_HIGH);
	DIO_voidSetPinValue(LCD_U8_RW,DIO_U8_LOW);
	
    #if LCD_U8_DATA_LENGTH  == LCD_U8_4_BIT
	if(GET_BIT(Copy_u8Data , 4) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 5) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 6) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Data , 7) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_LOW);
	}
	
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_HIGH);
	_delay_ms(1);
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_LOW);
	_delay_ms(1);	

	if(GET_BIT(Copy_u8Data , 0) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 1) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 2) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Data , 3) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_LOW);
	}

	
	#elif LCD_U8_DATA_LENGTH  == LCD_U8_8_BIT
	if(GET_BIT(Copy_u8Data , 0) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D0,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D0,DIO_U8_LOW);
	}
	
	if(GET_BIT(Copy_u8Data , 1) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D1,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D1,DIO_U8_LOW);
	}
	
	if(GET_BIT(Copy_u8Data , 2) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D2,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D2,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Data , 3) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D3,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D3,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 4) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 5) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Data , 6) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Data , 7) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_LOW);
	}	
	
	#endif
	
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_HIGH);
	_delay_ms(1);
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_LOW);
	_delay_ms(1);
	
}
void LCD_voidSendCommand(u8 Copy_u8Command)
{
	DIO_voidSetPinValue(LCD_U8_RS,DIO_U8_LOW);
	DIO_voidSetPinValue(LCD_U8_RW,DIO_U8_LOW);
    #if LCD_U8_DATA_LENGTH  == LCD_U8_4_BIT
	
	if(GET_BIT(Copy_u8Command , 4) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Command , 5) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Command , 6) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Command , 7) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_LOW);
	}
	
	
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_HIGH);
	_delay_ms(1);
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_LOW);
	_delay_ms(1);	
	
		if(GET_BIT(Copy_u8Command , 0) == 1)
		{
			DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_HIGH);
		}
		else
		{
			DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_LOW);
		}


		if(GET_BIT(Copy_u8Command , 1) == 1)
		{
			DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_HIGH);
		}
		else
		{
			DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_LOW);
		}


		if(GET_BIT(Copy_u8Command , 2) == 1)
		{
			DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_HIGH);
		}
		else
		{
			DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_LOW);
		}

		if(GET_BIT(Copy_u8Command , 3) == 1)
		{
			DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_HIGH);
		}
		else
		{
			DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_LOW);
		}
	
	#elif LCD_U8_DATA_LENGTH  == LCD_U8_8_BIT
	if(GET_BIT(Copy_u8Command , 0) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D0,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D0,DIO_U8_LOW);
	}
	
	if(GET_BIT(Copy_u8Command , 1) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D1,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D1,DIO_U8_LOW);
	}
	
	if(GET_BIT(Copy_u8Command , 2) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D2,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D2,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Command , 3) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D3,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D3,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Command , 4) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D4,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Command , 5) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D5,DIO_U8_LOW);
	}


	if(GET_BIT(Copy_u8Command , 6) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D6,DIO_U8_LOW);
	}

	if(GET_BIT(Copy_u8Command , 7) == 1)
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_HIGH);
	}
	else
	{
		DIO_voidSetPinValue(LCD_U8_D7,DIO_U8_LOW);
	}	
	
	#endif
	
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_HIGH);
	_delay_ms(1);
	DIO_voidSetPinValue(LCD_U8_E,DIO_U8_LOW);
	_delay_ms(1);
	
}
void LCD_voidSendString(s8* P_s8String)
{
	u8 Local_u8Counter = 0;
	while(P_s8String[Local_u8Counter] != '\0')
	{
		LCD_voidSendData(P_s8String[Local_u8Counter]);
		Local_u8Counter++;
	}
}

void LCD_voidSetCursor(u8 Copy_u8Row , u8 Copy_u8Column)
{
	u8 Local_u8Address = 0x80;
	switch(Copy_u8Row)
	{
		case LCD_U8_ROW_1:
			Local_u8Address = 0x80 + Copy_u8Column;
		break;
		case LCD_U8_ROW_2:
			Local_u8Address = 0xC0 + Copy_u8Column;
		break;
	}
	LCD_voidSendCommand(Local_u8Address);
}

void LCD_voidCustomChar(u8 Copy_u8Location , s8* Copy_u8Char)
{
	LCD_voidSendCommand(Copy_u8Location); // Goto CGRAM
	_delay_ms(1);
	//LCD_voidSendString(Copy_u8Char);
	for(u8 i = 0; i < 8; i++)
	{
		LCD_voidSendData(Copy_u8Char[i]);
	}
}

void LCD_voidClearDisp(void)
{
	LCD_voidSendCommand(0x01);
}

void LCD_voidShiftDisp(void)
{
	LCD_voidSendCommand(0x1C);  //shifts display to the right, cursor follows display shift 00011100
}
