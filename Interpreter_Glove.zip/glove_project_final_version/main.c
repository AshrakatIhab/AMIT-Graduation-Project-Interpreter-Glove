/*
 * Glove_Project_Version_7.c
 *
 * Created: 28/02/2023 3:57:24 PM
 * Author : Peter, Ashrakat, Sherry
 */ 


#include	"service/STD_Types.h"
#define		F_CPU 16000000UL
#include	<util/delay.h>

#include	"APP/Glove_Project_Interface.h"

int main(void)
{
	void_Application_Initialization();
	
	u8 ADC_Signals[5];
	u8 u8_Signal_Number;
	
	u16 Signs_EEPROM[15];
	u16 Signals_EEPROM[15];
	
	void_Store_Signs(Signs_EEPROM, Signals_EEPROM);

	while (1)
	{
		void_Get_ADC_Signals(ADC_Signals);
		
		u8_Signal_Number=u8_Search_Database(ADC_Signals, Signals_EEPROM);
		
		void_Display_Sign(u8_Signal_Number,Signs_EEPROM);
		
		_delay_ms(500);
	}
}
