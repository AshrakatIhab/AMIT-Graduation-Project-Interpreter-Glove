/*
 * Glove_Project_Interface.h
 *
 * Created: 09/02/2023 9:32:02 PM
 *  Author: Dell
 */ 


#ifndef GLOVE_PROJECT_INTERFACE_H_
#define GLOVE_PROJECT_INTERFACE_H_

void void_Application_Initialization(void); //Initializes all required drivers
void void_Store_Signs(u16 * Signs_EEPROM, u16 * Signals_EEPROM); //Stores signs and their signals in external EEPROM
void void_Get_ADC_Signals(u8* ADC_Signals); //Reads signals from sensors
u8 u8_Search_Database(u8* ADC_Signals, u16 * Signals_EEPROM); //Compares ADC signals to stored signals
void void_Display_Sign(u8 Copy_u8_Signal_Number,u16 * Signs_EEPROM); //Displays the signs when sensors match database





#endif /* GLOVE_PROJECT_INTERFACE_H_ */