/*
 * Glove_Project_Configurtion.h
 *
 * Created: 09/02/2023 9:32:39 PM
 *  Author: Dell
 */ 


#ifndef GLOVE_PROJECT_CONFIGURTION_H_
#define GLOVE_PROJECT_CONFIGURTION_H_

#define TOLERANCE				10
#define SIGN_MAX_NO_LETTERS		16

#define SIGN_1_NAME		"Awesome" 
#define SIGN_2_NAME		"Have a good life"
#define SIGN_3_NAME		"Yes"
#define SIGN_4_NAME		"O.K."
#define SIGN_5_NAME		"I'm watching you"
#define SIGN_6_NAME		"Peace"
#define SIGN_7_NAME		"You"
#define SIGN_8_NAME		"Perfect"
#define SIGN_9_NAME		"No"
#define SIGN_10_NAME	"I love you"
#define SIGN_11_NAME	"Hello"
#define SIGN_12_NAME	"Bathroom"
#define SIGN_13_NAME	"Seven"
#define SIGN_14_NAME	"I do love you"
#define SIGN_15_NAME	"Play"

#define	SIGN_1_VALUE_1	5
#define	SIGN_1_VALUE_2	118
#define	SIGN_1_VALUE_3	180
#define	SIGN_1_VALUE_4	180
#define	SIGN_1_VALUE_5	5

#define	SIGN_2_VALUE_1	5
#define	SIGN_2_VALUE_2	116
#define	SIGN_2_VALUE_3	125
#define	SIGN_2_VALUE_4	122
#define	SIGN_2_VALUE_5	5

#define	SIGN_3_VALUE_1	250
#define	SIGN_3_VALUE_2	169
#define	SIGN_3_VALUE_3	185
#define	SIGN_3_VALUE_4	185
#define	SIGN_3_VALUE_5	5

#define	SIGN_4_VALUE_1	5
#define	SIGN_4_VALUE_2	180
#define	SIGN_4_VALUE_3	180
#define	SIGN_4_VALUE_4	180
#define	SIGN_4_VALUE_5	5

#define	SIGN_5_VALUE_1	5
#define	SIGN_5_VALUE_2	163
#define	SIGN_5_VALUE_3	170
#define	SIGN_5_VALUE_4	172
#define	SIGN_5_VALUE_5	5

#define	SIGN_6_VALUE_1	5
#define	SIGN_6_VALUE_2	118
#define	SIGN_6_VALUE_3	130
#define	SIGN_6_VALUE_4	182
#define	SIGN_6_VALUE_5	5

#define	SIGN_7_VALUE_1	5
#define	SIGN_7_VALUE_2	123
#define	SIGN_7_VALUE_3	172
#define	SIGN_7_VALUE_4	167
#define	SIGN_7_VALUE_5	5

#define	SIGN_8_VALUE_1	5
#define	SIGN_8_VALUE_2	137
#define	SIGN_8_VALUE_3	136
#define	SIGN_8_VALUE_4	140
#define	SIGN_8_VALUE_5	5

#define	SIGN_9_VALUE_1	250
#define	SIGN_9_VALUE_2	125
#define	SIGN_9_VALUE_3	142
#define	SIGN_9_VALUE_4	179
#define	SIGN_9_VALUE_5	5

#define	SIGN_10_VALUE_1	250
#define	SIGN_10_VALUE_2	115
#define	SIGN_10_VALUE_3	178
#define	SIGN_10_VALUE_4	171
#define	SIGN_10_VALUE_5	5

#define	SIGN_11_VALUE_1 250
#define	SIGN_11_VALUE_2	123
#define	SIGN_11_VALUE_3	139
#define	SIGN_11_VALUE_4	145
#define	SIGN_11_VALUE_5	5

#define	SIGN_12_VALUE_1	5
#define	SIGN_12_VALUE_2	142
#define	SIGN_12_VALUE_3	160
#define	SIGN_12_VALUE_4	153
#define	SIGN_12_VALUE_5	5

#define	SIGN_13_VALUE_1	250
#define	SIGN_13_VALUE_2	121
#define	SIGN_13_VALUE_3	125
#define	SIGN_13_VALUE_4	180
#define	SIGN_13_VALUE_5	5

#define	SIGN_14_VALUE_1	5
#define	SIGN_14_VALUE_2	111
#define	SIGN_14_VALUE_3	140
#define	SIGN_14_VALUE_4	157
#define	SIGN_14_VALUE_5	5

#define	SIGN_15_VALUE_1	5
#define	SIGN_15_VALUE_2	155
#define	SIGN_15_VALUE_3	171
#define	SIGN_15_VALUE_4	152
#define	SIGN_15_VALUE_5	5


#endif /* GLOVE_PROJECT_CONFIGURTION_H_ */