/*
 * Glove_Project_Program.c
 *
 * Created: 09/02/2023 9:33:28 PM
 *  Author: Dell
 */ 

#include "../service/STD_types.h"
#define  F_CPU 16000000UL
#include <util/delay.h>

#include	"../MCAL/MCAL_DIO/DIO_int.h"
#include	"../MCAL/MCAL_TWI/TWI_int.h"
#include	"../HAL/HAL_EEPROM/EEPROM_int.h"
#include	"../HAL/HAL_LCD/LCD_int.h"
#include	"../MCAL/MCAL_ADC/ADC_int.h"

#include	"../APP/Glove_Project_Configurtion.h"
#include	"../APP/Glove_Project_Interface.h"

void void_Application_Initialization(void)
{
	DIO_voidInit();
	LCD_voidInit();
	
	//Display Process phases for interfacing purposes
	LCD_voidClearDisp();
	LCD_voidSetCursor(0,0);
	LCD_voidSendString("   Welcome to   ");
	_delay_ms(2000);
	LCD_voidClearDisp();
	LCD_voidSetCursor(0,0);
	LCD_voidSendString("   Interpreter  ");
	LCD_voidSetCursor(1,0);
	LCD_voidSendString("      Glove     ");
	_delay_ms(3000);
	
	//Display Process phases for interfacing purposes
	LCD_voidClearDisp();
	LCD_voidSetCursor(0,0);
	LCD_voidSendString("Initializing ...");
	
	TWI_voidInit();
	EEPROM_voidInit();
	ADC_voidInit();
	
	//Display Process phases for interfacing purposes
	LCD_voidClearDisp();
	LCD_voidSetCursor(0,0);
	LCD_voidSendString("Successfully");
	LCD_voidSetCursor(1,0);
	LCD_voidSendString("done");
	_delay_ms(1000);
	LCD_voidClearDisp();
}

void void_Store_Signs(u16 * Signs_EEPROM, u16 * Signals_EEPROM)
{
	//Display Process phases for interfacing purposes
	LCD_voidClearDisp();
	LCD_voidSetCursor(0,0);
	LCD_voidSendString("Storing signs ");
	LCD_voidSetCursor(1,0);
	LCD_voidSendString("into EEPROM ");
	_delay_ms(500);
	LCD_voidSendString("...");
	
	u8 u8Arr_sign_1 []=SIGN_1_NAME;
	u8 u8Arr_sign_2 []=SIGN_2_NAME;
	u8 u8Arr_sign_3 []=SIGN_3_NAME;
	u8 u8Arr_sign_4 []=SIGN_4_NAME;
	u8 u8Arr_sign_5 []=SIGN_5_NAME;
	u8 u8Arr_sign_6 []=SIGN_6_NAME;
	u8 u8Arr_sign_7 []=SIGN_7_NAME;
	u8 u8Arr_sign_8 []=SIGN_8_NAME;
	u8 u8Arr_sign_9 []=SIGN_9_NAME;
	u8 u8Arr_sign_10[]=SIGN_10_NAME;
	u8 u8Arr_sign_11[]=SIGN_11_NAME;
	u8 u8Arr_sign_12[]=SIGN_12_NAME;
	u8 u8Arr_sign_13[]=SIGN_13_NAME;
	u8 u8Arr_sign_14[]=SIGN_14_NAME;
	u8 u8Arr_sign_15[]=SIGN_15_NAME;
	
	u8 u8ARR_signs_Values[15][5]={	{SIGN_1_VALUE_1,SIGN_1_VALUE_2,SIGN_1_VALUE_3,SIGN_1_VALUE_4,SIGN_1_VALUE_5},
									{SIGN_2_VALUE_1,SIGN_2_VALUE_2,SIGN_2_VALUE_3,SIGN_2_VALUE_4,SIGN_2_VALUE_5},
									{SIGN_3_VALUE_1,SIGN_3_VALUE_2,SIGN_3_VALUE_3,SIGN_3_VALUE_4,SIGN_3_VALUE_5},
									{SIGN_4_VALUE_1,SIGN_4_VALUE_2,SIGN_4_VALUE_3,SIGN_4_VALUE_4,SIGN_4_VALUE_5},
									{SIGN_5_VALUE_1,SIGN_5_VALUE_2,SIGN_5_VALUE_3,SIGN_5_VALUE_4,SIGN_5_VALUE_5},
									{SIGN_6_VALUE_1,SIGN_6_VALUE_2,SIGN_6_VALUE_3,SIGN_6_VALUE_4,SIGN_6_VALUE_5},
									{SIGN_7_VALUE_1,SIGN_7_VALUE_2,SIGN_7_VALUE_3,SIGN_7_VALUE_4,SIGN_7_VALUE_5},
									{SIGN_8_VALUE_1,SIGN_8_VALUE_2,SIGN_8_VALUE_3,SIGN_8_VALUE_4,SIGN_8_VALUE_5},
									{SIGN_9_VALUE_1,SIGN_9_VALUE_2,SIGN_9_VALUE_3,SIGN_9_VALUE_4,SIGN_9_VALUE_5},
									{SIGN_10_VALUE_1,SIGN_10_VALUE_2,SIGN_10_VALUE_3,SIGN_10_VALUE_4,SIGN_10_VALUE_5},
									{SIGN_11_VALUE_1,SIGN_11_VALUE_2,SIGN_11_VALUE_3,SIGN_11_VALUE_4,SIGN_11_VALUE_5},
									{SIGN_12_VALUE_1,SIGN_12_VALUE_2,SIGN_12_VALUE_3,SIGN_12_VALUE_4,SIGN_12_VALUE_5},
									{SIGN_13_VALUE_1,SIGN_13_VALUE_2,SIGN_13_VALUE_3,SIGN_13_VALUE_4,SIGN_13_VALUE_5},
									{SIGN_14_VALUE_1,SIGN_14_VALUE_2,SIGN_14_VALUE_3,SIGN_14_VALUE_4,SIGN_14_VALUE_5},
									{SIGN_15_VALUE_1,SIGN_15_VALUE_2,SIGN_15_VALUE_3,SIGN_15_VALUE_4,SIGN_15_VALUE_5}};
	
	
	//USE Array of addresses to limit the code size
	u8* array_of_addresses [15]={u8Arr_sign_1, 
								  u8Arr_sign_2, 
								  u8Arr_sign_3, 
								  u8Arr_sign_4, 
								  u8Arr_sign_5, 
								  u8Arr_sign_6, 
								  u8Arr_sign_7, 
								  u8Arr_sign_8, 
								  u8Arr_sign_9, 
								  u8Arr_sign_10,
								  u8Arr_sign_11,
								  u8Arr_sign_12,
								  u8Arr_sign_13,
								  u8Arr_sign_14,
								  u8Arr_sign_15
		};
	
	u8 u8_Sign_Letter_Counter = 0;
	u16 u16_address_holder = 0;
	u8	u8_Sign_Index_Number = 0;
	
	for(u8_Sign_Index_Number=0;u8_Sign_Index_Number<15;u8_Sign_Index_Number++)
	{
	
		while(array_of_addresses [u8_Sign_Index_Number][u8_Sign_Letter_Counter] != '\0')
		{
			
			
			EEPROM_VoidWriteByte(u16_address_holder,array_of_addresses [u8_Sign_Index_Number][u8_Sign_Letter_Counter]);
			_delay_ms(20);
			if (u8_Sign_Letter_Counter == 0)	//if we start at the first letter of the sign name
			{
				//store this base address of the sign in the array (Signs_EEPROM)
				Signs_EEPROM[u8_Sign_Index_Number]=u16_address_holder;
			}
			u8_Sign_Letter_Counter++;
			u16_address_holder++;
		}
		u8_Sign_Letter_Counter=0;
		
		EEPROM_VoidWriteByte(u16_address_holder,'\0');
		_delay_ms(20);
		u16_address_holder++;
	}
	//////////////////////////////////////////////////////////////////////////
	
	//Storing Signs Values and Save the base address of the Values in the Signs_Names_Addresses_Array
	for(u8_Sign_Index_Number=0;u8_Sign_Index_Number<15;u8_Sign_Index_Number++)
	{
		for(u8 value_counter=0;value_counter<5;value_counter++)
		{
			
			EEPROM_VoidWriteByte(u16_address_holder,u8ARR_signs_Values[u8_Sign_Index_Number][value_counter]);
			_delay_ms(20);
			if (value_counter == 0)	//if we start at the first value of the sign
			{
				//store this base address of the sign value in the array (Signals_EEPROM)
				Signals_EEPROM[u8_Sign_Index_Number]=u16_address_holder;
			}
			u16_address_holder++;
		}
	}
	
	//Display Process phases for interfacing purposes
	LCD_voidClearDisp();
	LCD_voidSetCursor(0,0);
	LCD_voidSendString("Successfully");
	LCD_voidSetCursor(1,0);
	LCD_voidSendString("done");
	_delay_ms(1000);
	LCD_voidClearDisp();
	
}

void void_Get_ADC_Signals(u8* ADC_Signals)
{
	ADC_Signals[0]= ADC_u8Convert(ADC_U8_Channel0);
	ADC_Signals[1]= ADC_u8Convert(ADC_U8_Channel4);
	ADC_Signals[2]= ADC_u8Convert(ADC_U8_Channel5);
	ADC_Signals[3]= ADC_u8Convert(ADC_U8_Channel6);
	ADC_Signals[4]= ADC_u8Convert(ADC_U8_Channel7);
}

u8 u8_Search_Database(u8* ADC_Signals, u16 * Signals_EEPROM)
{		
	u8 sign_number=0;
	u16 signal_number=0;
	u8 Ref_Signals;
	u8 counter=0;	
	for(sign_number=0; sign_number<15; sign_number++) //0 - 14
	{
		for(signal_number=0; signal_number<5;signal_number++) //0 - 4
		{
			Ref_Signals=EEPROM_u8ReadByte(Signals_EEPROM[sign_number]+signal_number);
			
			if((ADC_Signals[signal_number]>=(Ref_Signals-TOLERANCE)) && (ADC_Signals[signal_number]<(Ref_Signals+TOLERANCE)))
			{
				counter++;
			}
			else
			{
				break;
			}	
		}
		if(counter == 5)
		{
			break;
		}
		counter = 0;
	}
	return sign_number;
}

void void_Display_Sign(u8 Copy_u8_Signal_Number,u16 * Signs_EEPROM)
{
	if(Copy_u8_Signal_Number < 15)
	{
	//LCD initialization will be only one time in the main
	
	u8 u8_char_holder=0;
	u16 i=0;
	u8_char_holder=EEPROM_u8ReadByte(Signs_EEPROM[Copy_u8_Signal_Number]);
		
	LCD_voidClearDisp();
	LCD_voidSetCursor(0, 0);

	while(u8_char_holder != '\0')
	{
		LCD_voidSendData(u8_char_holder);
		i++;
		u8_char_holder=EEPROM_u8ReadByte((Signs_EEPROM[Copy_u8_Signal_Number]+i));
		_delay_ms(5);
	}
	}
	else
	{
		
		LCD_voidSetCursor(0, 0);
		LCD_voidSendString("...");
	}
}
